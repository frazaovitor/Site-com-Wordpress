// Configuração do firebase
var firebaseConfig = {
    apiKey: "AIzaSyCVncHPH41xtwIGisJtwgiuEt2JHwKGlRY",
    authDomain: "mecriptando.firebaseapp.com",
    databaseURL: "https://mecriptando.firebaseio.com",
    projectId: "mecriptando",
    storageBucket: "mecriptando.appspot.com",
    messagingSenderId: "104939382579",
    appId: "1:104939382579:web:f9a21c409c1aa982e70046"
};
// inicialização do Firebase
firebase.initializeApp(firebaseConfig);

