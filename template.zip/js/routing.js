
//Carrega a página "home.html"
load('pages/home.html');

//monitora os links

linkMonitor();
function linkMonitor() {
    //Referência a todos os links
    var links = document.getElementsByTagName('a');
    //obtendo cada <a>
    for (var i = 0; i < links.length; i++) {
        //Cria monitor de links
        links[i].addEventListener('click', routing, false);
    }
}
//função que prepara o link
function routing(ev) {
    //bloqueia a ação normal do HTML
    ev.preventDefault();

    var href = this.getAttribute('href');
    //verifica se clicou no botão #menu
    if (href == '#menu') return false;

    //verifica se o link.href comeca com "#"
    if (href.substr(0, 1) == '#') {

        //carrega a página correspondente
        var pg = href.substr(1);
        load('pages/' + pg + '.html');

        hideMenu();
    } else {

        window.open(href);
    }
}

//carrega a página do AJAX na <main>
function load(page) {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            $('main').innerHTML = this.responseText;
            linkMonitor();
        }
    };
    xhttp.open("GET", page, true);
    xhttp.send();
}