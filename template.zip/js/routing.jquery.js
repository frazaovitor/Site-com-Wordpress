$(document).ready(runRoutes);

function runRoutes() {
    //carrega a página principal
    $.get('pages/home.html', '', function (data) {
        $('#main').html(data);
    });
}

//monitora os links
$(document).on('click', 'a', routing);

//roteamento
function routing(e) {
    //evita a ação normal do link no html
    e.preventDefault();

    //obtem  o link da tag 'a' clicada
    var href = $(this).attr('href');


    //se clicou no botão menu
    if (href == '#menu') return false;

    //se clicou em uma rota que inicia com #
    if (href.substr(0, 1) == '#') {
        //remove o //#endregion
        var pg = href.substr(1);

        var doc = 'pages/' + pg + '.html';

        //carrega o documento
        $.get(doc,'',function(data){

            //grava o documento na tag 'main'

            $('#main').html(data);

            //oculta o menu
            hideMenu();
        });
    }else{
        //executar o link em nova janela
        window.open(hfref);
    }

}
