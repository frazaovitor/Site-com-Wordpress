// Executa o programa principal quando o documento for carregado
$(document).ready(myApp);

// Programa principal
function myApp(){
    // Detectar cliques no botão menu
    $(document).on('click','#btnMenu',toggleMenu);

}

// Controle do menu
function toggleMenu(e){

    e.preventDefault();
    if($('#nav').is(':visible'))  //Se o menu está visivel
        hideMenu();               //Oculta o menu
    else
        showMenu();
}
//Detectar cliques no fundo do menu
$(document).on('click','#modalMenu', hideMenu);

//Oculta menu
function hideMenu(){
    $('#btnMenu i').removeClass('fa-rotate-180');
    $('#nav').slideUp('fast'); 
    $('#modalMenu').slideUp('fast'); 
}

//Mostra o menu
function showMenu(){
    $('#btnMenu i').addClass('fa-rotate-180');
    $('#nav').slideDown('fast'); 
    $('#modalMenu').slideDown('fast');
}

function _(txtlog){
    console.log(txtlog);
}


