/*****************************/
/*JavaScript princiapl do app*/
/*****************************/

//Referência dos elementos

//Função que serve de atalho para "documento.getElementById"
function $(objId) {
    return document.getElementById(objId);
}

//Botão do menu
var btnMenu = $('btnMenu');

//Menu principal
var nav = $('nav');

//Fundo do menu 
var modalMenu = $('modalMenu');

//Ajustes iniciais
hideMenu();

//Quando clicar no botão do menu
btnMenu.addEventListener('click', toggleMenu, false);

//Função modal menu
function toggleMenu() {
    event.preventDefault();
    if (nav.style.display == 'none')
        showMenu();
    else
        hideMenu();
    return false;
}

//Quando clicar no modal
modalMenu.addEventListener('click', hideMenu, false);

//Função que mostra o menu
function showMenu() {

    modalMenu.style.display = 'block';
    nav.style.display = 'block';
    btnMenu.getElementsByTagName('i')[0].classList.add('fa-rotate-180');
    //btnMenu.innerHTML = '<i class="far fa-fw fa-caret-square-up"></i>'
}


//Função que oculta o menu
function hideMenu() {
    nav.style.display = 'none';
    modalMenu.style.display = 'none';
    btnMenu.getElementsByTagName('i')[0].classList.remove('fa-rotate-180');
    //btnMenu.innerHTML = '<i class="far fa-fw fa-caret-square-down"></i>'
}

//função que serve de atalho para console.log('')

function _(txtlog){
    console.log(txtlog);
}

