//instancia do firebase auth do google
var provider = new firebase.auth.GoogleAuthProvider();

//usa o idioma do nabegador
firebase.auth().useDeviceLanguage();

//monitora se usuario logou ou não
firebase.auth().onAuthStateChanged(function (user) {
    if (user) {
        // User is signed in.

        _(user);
        // ...
    } else {
        // User is signed out.
        // ...
        _('Nunguém logado!');
    }
});

//faz login no provedor de autenticação
function login() {
    firebase.auth().signInWithPopup(provider).then(function (result) {

        // obtem dados do usuario que se logou
        var user = result.user;
        // ...
        _(user);

    }).catch(function (error) {

        _(error);
    });
}

//faz logout do usuario
function logout() {
    firebase.auth().signOut().then(function () {
        _('usuário saiu!');
    }).catch(function (error) {
        _('usuário nao conseguiu sair: ' + error);
    });
}