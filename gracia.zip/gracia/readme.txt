Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/gracia/
Buy theme: http://smthemes.com/buy/gracia/
Support Forums: http://smthemes.com/support/forum/gracia-free-wordpress-theme/